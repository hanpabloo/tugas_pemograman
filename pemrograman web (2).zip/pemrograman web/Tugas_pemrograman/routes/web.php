<?php

use Illuminate\Support\Facades\Route; // Mengimpor facade Route untuk mendefinisikan rute
use App\Http\Controllers\ChirpController; // Mengimpor ChirpController untuk menangani logika bisnis

// Mendefinisikan rute untuk halaman beranda
Route::get('/', function () {
    return view('welcome'); // Mengembalikan view 'welcome' ketika mengakses rute '/'
});

// Mendefinisikan resource route untuk 'chirps'
// Hapus middleware auth agar route chirps bisa diakses tanpa login
Route::resource('chirps', ChirpController::class); // Membuat semua rute yang diperlukan untuk resource chirps
