<?php

namespace App\Http\Controllers; // Menentukan namespace untuk controller ini

use App\Models\Chirp; // Mengimpor model Chirp
use Illuminate\Http\Request; // Mengimpor kelas Request untuk menangani input HTTP

class ChirpController extends Controller // Mendefinisikan kelas ChirpController yang mengextends kelas Controller
{
    public function index() // Metode untuk menampilkan semua chirps
    {
        // Mengambil semua chirps dengan pengguna terkait, terurut dari yang terbaru
        $chirps = Chirp::with('user')->latest()->get(); 
        return view('chirps.index', compact('chirps')); // Mengembalikan tampilan dengan data chirps
    }
    
    public function store(Request $request) // Metode untuk menyimpan chirp baru
    {
        // Validasi input
        $request->validate([
            'message' => 'required|max:255', // Pesan harus ada dan maksimal 255 karakter
        ]);
    
        // Membuat chirp baru
        $chirp = new Chirp(); // Membuat instance baru dari model Chirp
        // Mengatur user_id menjadi null jika tidak menggunakan autentikasi
        $chirp->user_id = null; // Atau set ID pengguna yang sesuai, jika ada autentikasi
        $chirp->message = $request->message; // Mengatur pesan chirp
        $chirp->save(); // Menyimpan chirp ke database
    
        return redirect()->route('chirps.index')->with('success', 'Chirp berhasil dibuat!'); // Mengalihkan ke index dengan pesan sukses
    }
    

    public function edit(Chirp $chirp) // Metode untuk menampilkan form edit chirp
    {
        return view('chirps.edit', compact('chirp')); // Mengembalikan tampilan edit dengan data chirp
    }

    public function destroy(Chirp $chirp) // Metode untuk menghapus chirp
    {
        // Menghapus chirp
        $chirp->delete(); // Menghapus chirp dari database

        return redirect()->route('chirps.index')->with('success', 'Chirp berhasil dihapus!'); // Mengalihkan kembali dengan pesan sukses
    }

    public function update(Request $request, Chirp $chirp) // Metode untuk memperbarui chirp yang ada
    {
        // Validasi input
        $request->validate([
            'message' => 'required|max:255', // Pesan harus ada dan maksimal 255 karakter
        ]);

        // Memperbarui pesan chirp
        $chirp->message = $request->message; // Mengatur pesan baru
        $chirp->save(); // Menyimpan perubahan ke database

        return redirect()->route('chirps.index')->with('success', 'Chirp berhasil diperbarui!'); // Mengalihkan kembali dengan pesan sukses
    }
}
