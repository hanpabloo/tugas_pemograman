<?php

namespace App\Models; // Menentukan namespace dari model ini

use Illuminate\Database\Eloquent\Factories\HasFactory; // Mengimpor trait HasFactory untuk mendukung pembuatan factory
use Illuminate\Database\Eloquent\Model; // Mengimpor kelas Model sebagai kelas dasar untuk semua model

class Chirp extends Model // Mendefinisikan kelas Chirp yang mengextends kelas Model
{
    use HasFactory; // Menggunakan trait HasFactory

    protected $fillable = ['user_id', 'message']; // Menentukan kolom yang dapat diisi secara massal (mass assignment)

    public function user() // Metode untuk mendefinisikan relasi dengan model User
    {
        return $this->belongsTo(User::class); // Menyatakan bahwa setiap chirp milik satu pengguna
    }
}

