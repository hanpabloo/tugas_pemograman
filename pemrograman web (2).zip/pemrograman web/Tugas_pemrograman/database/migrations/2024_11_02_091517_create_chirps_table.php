<?php

use Illuminate\Database\Migrations\Migration; // Mengimpor kelas Migration untuk membuat migrasi
use Illuminate\Database\Schema\Blueprint; // Mengimpor kelas Blueprint untuk mendefinisikan skema tabel
use Illuminate\Support\Facades\Schema; // Mengimpor kelas Schema untuk interaksi dengan database schema

return new class extends Migration // Mendefinisikan kelas anonim yang mengextends kelas Migration
{
    public function up() // Metode yang dijalankan saat migrasi diaktifkan
    {
        Schema::create('chirps', function (Blueprint $table) { // Membuat tabel 'chirps'
            $table->id(); // Menambahkan kolom 'id' sebagai primary key

            // Mengatur user_id sebagai nullable dan menambahkan foreign key constraint
            $table->foreignId('user_id')->nullable()->constrained()->onDelete('cascade'); 
            // user_id dapat bernilai NULL, mengacu pada kolom 'id' di tabel 'users', dan jika pengguna dihapus, semua chirps terkait juga dihapus.

            $table->text('message'); // Menambahkan kolom 'message' untuk menyimpan isi chirp
            $table->timestamps(); // Menambahkan kolom 'created_at' dan 'updated_at' untuk mencatat waktu penciptaan dan pembaruan
        });
    }

    public function down(): void // Metode yang dijalankan saat migrasi dibatalkan
    {
        Schema::dropIfExists('chirps'); // Menghapus tabel 'chirps' jika ada
    }
};
