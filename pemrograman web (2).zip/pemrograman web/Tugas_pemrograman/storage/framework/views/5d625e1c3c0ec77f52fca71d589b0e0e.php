 

<?php $__env->startSection('content'); ?> 
<div class="container"> 
    <h1 class="text-center my-4">Chirps</h1> 

    
    <?php if(session('success')): ?> 
        <div class="alert alert-success"> 
            <?php echo e(session('success')); ?> 
        </div>
    <?php endif; ?>

    
    <div class="card mb-4"> 
        <div class="card-body"> 
            <form action="<?php echo e(route('chirps.store')); ?>" method="POST"> 
                <?php echo csrf_field(); ?> 
                <div class="form-group"> 
                    <label for="message">Create Chirp</label> 
                    <textarea class="form-control" id="message" name="message" rows="3" placeholder="What's on your mind?" required></textarea> 
                </div>
                <button type="submit" class="btn btn-primary mt-2">Post Chirp</button> 
            </form>
        </div>
    </div>

    
    <h2 class="mb-3">All Chirps</h2> 
    <?php $__currentLoopData = $chirps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chirp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <div class="card my-3"> 
        <div class="card-body"> 
            <h5 class="card-title">
                <?php echo e($chirp->user ? $chirp->user->name : 'Unknown User'); ?> 
            </h5>
            <p class="card-text"><?php echo e($chirp->message); ?></p> 
            <p class="text-muted"><?php echo e($chirp->created_at->diffForHumans()); ?></p> 

            
            <?php if(auth()->id() === $chirp->user_id): ?>
                
                <a href="<?php echo e(route('chirps.edit', $chirp->id)); ?>" class="btn btn-warning">Edit</a> 

                <form action="<?php echo e(route('chirps.destroy', $chirp->id)); ?>" method="POST" class="d-inline"> 
                    <?php echo csrf_field(); ?> 
                    <?php echo method_field('DELETE'); ?> 
                    <button type="submit" class="btn btn-danger">Delete</button> 
                </form>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

</div>
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp2\htdocs\Tugas_Makasum\resources\views/chirps/index.blade.php ENDPATH**/ ?>