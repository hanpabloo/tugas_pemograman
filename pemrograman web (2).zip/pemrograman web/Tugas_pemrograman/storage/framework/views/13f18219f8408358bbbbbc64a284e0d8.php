

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Chirp</h1>

    <form action="<?php echo e(route('chirps.update', $chirp->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="message">Message</label>
            <textarea class="form-control" id="message" name="message" rows="3" required><?php echo e($chirp->message); ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary mt-2">Update Chirp</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp2\htdocs\Tugas_Makasum\resources\views/chirps/edit.blade.php ENDPATH**/ ?>