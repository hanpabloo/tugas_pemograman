@extends('layouts.app') {{-- Menggunakan layout utama dari aplikasi --}}

@section('content') {{-- Memulai section 'content' yang akan ditampilkan di layout --}}
<div class="container"> {{-- Membungkus konten dalam div dengan kelas 'container' untuk styling --}}
    <h1 class="text-center my-4">Chirps</h1> {{-- Judul halaman ditampilkan di tengah dengan margin atas dan bawah --}}

    {{-- Tampilkan pesan sukses jika ada --}}
    @if (session('success')) {{-- Memeriksa apakah ada pesan sukses di session --}}
        <div class="alert alert-success"> {{-- Jika ada, tampilkan dalam div alert --}}
            {{ session('success') }} {{-- Menampilkan pesan sukses --}}
        </div>
    @endif

    {{-- Form untuk membuat chirp baru --}}
    <div class="card mb-4"> {{-- Membungkus form dalam card dengan margin bawah --}}
        <div class="card-body"> {{-- Bagian isi dari card --}}
            <form action="{{ route('chirps.store') }}" method="POST"> {{-- Form untuk mengirim data chirp baru --}}
                @csrf {{-- Menyertakan token CSRF untuk keamanan --}}
                <div class="form-group"> {{-- Mengelompokkan elemen form --}}
                    <label for="message">Create Chirp</label> {{-- Label untuk textarea --}}
                    <textarea class="form-control" id="message" name="message" rows="3" placeholder="What's on your mind?" required></textarea> {{-- Textarea untuk input pesan --}}
                </div>
                <button type="submit" class="btn btn-primary mt-2">Post Chirp</button> {{-- Tombol untuk mengirim form --}}
            </form>
        </div>
    </div>

    {{-- Daftar chirp --}}
    <h2 class="mb-3">All Chirps</h2> {{-- Subjudul untuk daftar chirp --}}
    @foreach ($chirps as $chirp) {{-- Iterasi melalui setiap chirp --}}
    <div class="card my-3"> {{-- Membungkus setiap chirp dalam card --}}
        <div class="card-body"> {{-- Bagian isi dari card --}}
            <h5 class="card-title">
                {{ $chirp->user ? $chirp->user->name : 'Unknown User' }} {{-- Menangani kasus jika user tidak ada --}}
            </h5>
            <p class="card-text">{{ $chirp->message }}</p> {{-- Menampilkan pesan chirp --}}
            <p class="text-muted">{{ $chirp->created_at->diffForHumans() }}</p> {{-- Menampilkan waktu pembuatan chirp dalam format 'beberapa detik yang lalu' --}}

            {{-- Tampilkan tombol edit dan delete hanya jika chirp milik user yang login --}}
            @if (auth()->id() === $chirp->user_id)
                {{-- Memeriksa apakah ID pengguna yang login sama dengan ID pengguna chirp --}}
                <a href="{{ route('chirps.edit', $chirp->id) }}" class="btn btn-warning">Edit</a> {{-- Tombol untuk mengedit chirp --}}

                <form action="{{ route('chirps.destroy', $chirp->id) }}" method="POST" class="d-inline"> {{-- Form untuk menghapus chirp --}}
                    @csrf {{-- Menyertakan token CSRF untuk keamanan --}}
                    @method('DELETE') {{-- Menyatakan bahwa metode HTTP yang digunakan adalah DELETE --}}
                    <button type="submit" class="btn btn-danger">Delete</button> {{-- Tombol untuk menghapus chirp --}}
                </form>
            @endif
        </div>
    </div>
    @endforeach {{-- Mengakhiri iterasi chirp --}}

</div>
@endsection {{-- Mengakhiri section 'content' --}}
