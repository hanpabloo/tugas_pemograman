@extends('layouts.app') {{-- Menggunakan layout utama dari aplikasi --}}

@section('content') {{-- Memulai section 'content' yang akan ditampilkan di layout --}}
<div class="container"> {{-- Membungkus konten dalam div dengan kelas 'container' untuk styling --}}
    <h1>Edit Chirp</h1> {{-- Judul halaman untuk pengeditan chirp --}}

    <form action="{{ route('chirps.update', $chirp->id) }}" method="POST"> {{-- Form untuk mengirim data ke route 'chirps.update' dengan ID chirp yang sedang diedit --}}
        @csrf {{-- Menyertakan token CSRF untuk keamanan --}}
        @method('PUT') {{-- Menyatakan bahwa metode HTTP yang digunakan adalah PUT untuk update --}}
        <div class="form-group"> {{-- Mengelompokkan elemen form --}}
            <label for="message">Message</label> {{-- Label untuk textarea --}}
            <textarea class="form-control" id="message" name="message" rows="3" required>{{ $chirp->message }}</textarea> {{-- Textarea untuk input pesan, diisi dengan pesan yang sudah ada --}}
        </div>
        <button type="submit" class="btn btn-primary mt-2">Update Chirp</button> {{-- Tombol untuk mengirim form --}}
    </form>
</div>
@endsection {{-- Mengakhiri section 'content' --}}
