@extends('layouts.app') {{-- Menggunakan layout utama dari aplikasi --}}

@section('content') {{-- Memulai section 'content' yang akan ditampilkan di layout --}}
<div class="container"> {{-- Membungkus konten dalam div dengan kelas 'container' untuk styling --}}
    <h1>Create New Chirp</h1> {{-- Judul halaman --}}

    <form action="{{ route('chirps.store') }}" method="POST"> {{-- Form untuk mengirim data ke route 'chirps.store' --}}
        @csrf {{-- Menyertakan token CSRF untuk keamanan --}}
        <div class="form-group"> {{-- Mengelompokkan elemen form --}}
            <label for="message">Message</label> {{-- Label untuk textarea --}}
            <textarea class="form-control" id="message" name="message" rows="3" required></textarea> {{-- Textarea untuk input pesan --}}
        </div>
        <button type="submit" class="btn btn-primary mt-2">Post Chirp</button> {{-- Tombol untuk mengirim form --}}
    </form>
</div>
@endsection {{-- Mengakhiri section 'content' --}}
